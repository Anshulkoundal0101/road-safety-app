import { useState } from 'react';
import './App.css';

function App() {
  const [jsonInput, setJsonInput] = useState('');
  const [error, setError] = useState('');
  const [responseData, setResponseData] = useState(null);
  const [selectedOptions, setSelectedOptions] = useState([]);

  const backendURL = 'http://localhost:3001/bfhl';

  const handleSubmit = async (e) => {
    e.preventDefault();
    let parsed;
    try {
      parsed = JSON.parse(jsonInput);
    } catch (err) {
      setError('Invalid JSON. Please enter valid JSON input.');
      return;
    }
    if (!parsed.data || !Array.isArray(parsed.data)) {
      setError('JSON must contain a "data" key with an array value.');
      return;
    }
    setError('');

    try {
      const res = await fetch(backendURL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(parsed),
      });
      const json = await res.json();
      setResponseData(json);
    } catch (err) {
      setError('Error calling backend API.');
    }
  };

  const handleDropdownChange = (e) => {
    const values = Array.from(e.target.selectedOptions, (option) => option.value);
    setSelectedOptions(values);
  };

  const renderFilteredResponse = () => {
    if (!responseData) return null;

    const filteredResponse = {};
    if (selectedOptions.includes('Alphabets')) {
      filteredResponse.alphabets = responseData.alphabets;
    }
    if (selectedOptions.includes('Numbers')) {
      filteredResponse.numbers = responseData.numbers;
    }
    if (selectedOptions.includes('Highest Alphabet')) {
      filteredResponse.highest_alphabet = responseData.highest_alphabet;
    }
    return (
      <div>
        {Object.entries(filteredResponse).map(([key, value]) => (
          <div key={key}>
            <strong>{key}:</strong> {JSON.stringify(value)}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Frontend Application</h1>
      <form onSubmit={handleSubmit}>
        <textarea
          placeholder='Enter JSON e.g. { "data": ["A", "C", "z"] }'
          rows="5"
          cols="50"
          value={jsonInput}
          onChange={(e) => setJsonInput(e.target.value)}
        />
        {error && <div style={{ color: 'red', marginTop: '10px' }}>{error}</div>}
        <button type="submit" style={{ marginTop: '10px' }}>
          Submit
        </button>
      </form>
      {responseData && (
        <div style={{ marginTop: '20px' }}>
          <h2>Select response fields to display</h2>
          <select multiple value={selectedOptions} onChange={handleDropdownChange}>
            <option value="Alphabets">Alphabets</option>
            <option value="Numbers">Numbers</option>
            <option value="Highest Alphabet">Highest Alphabet</option>
          </select>
          <div style={{ marginTop: '20px' }}>
            <h2>Response</h2>
            {renderFilteredResponse()}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
